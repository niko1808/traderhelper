export function getBinanceInterval(tf) {
  return tf;
}

export function formatCandle(c) {
  return c;
}

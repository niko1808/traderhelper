// Mouse / touch events del gráfico

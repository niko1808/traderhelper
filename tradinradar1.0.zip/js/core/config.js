export const CONFIG = {
  symbol: 'btcusdt',
  timeframe: '1m'
};

export const state = {
  drawingMode: null
};


export const appState = {
  market: 'crypto',
  symbol: 'BTCUSDT',
  timeframe: '1m'
};

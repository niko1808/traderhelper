export const FIB_LEVELS = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];

// Implementación canvas overlay (base)

import { state } from '../core/state.js';

export function setDrawingMode(mode) {
  state.drawingMode = mode;
}

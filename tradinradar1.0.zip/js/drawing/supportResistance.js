// Líneas horizontales
